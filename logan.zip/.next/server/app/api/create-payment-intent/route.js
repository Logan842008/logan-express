const CHUNK_PUBLIC_PATH = "server/app/api/create-payment-intent/route.js";
const runtime = require("../../../chunks/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/node_modules_75a59b._.js");
runtime.loadChunk("server/chunks/app_api_create-payment-intent_route_ts_732def._.js");
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/create-payment-intent/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)", CHUNK_PUBLIC_PATH).exports;
