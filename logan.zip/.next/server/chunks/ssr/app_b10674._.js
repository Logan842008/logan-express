module.exports = {

"[project]/app/data/sellingCarData.ts [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "bodyTypes": ()=>bodyTypes,
    "carBrands": ()=>carBrands,
    "carColors": ()=>carColors,
    "carFeatures": ()=>carFeatures,
    "driveType": ()=>driveType,
    "engineTechnologies": ()=>engineTechnologies,
    "engineTypes": ()=>engineTypes,
    "firebaseUtils": ()=>firebaseUtils,
    "fuelTypes": ()=>fuelTypes,
    "transmissionTypes": ()=>transmissionTypes
});
var __TURBOPACK__commonjs__external__tailwindcss$2f$colors__ = __turbopack_external_require__("tailwindcss/colors", true);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$auth$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/firebase/auth/dist/index.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$node$2d$esm$2f$totp$2d$67638892$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__o__as__getAuth$3e$__ = __turbopack_import__("[project]/node_modules/firebase/node_modules/@firebase/auth/dist/node-esm/totp-67638892.js [app-ssr] (ecmascript) <export o as getAuth>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$firestore$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/firebase/firestore/dist/index.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@firebase/firestore/dist/index.node.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/config.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$storage$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_import__("[project]/node_modules/firebase/storage/dist/index.mjs [app-ssr] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$storage$2f$dist$2f$node$2d$esm$2f$index$2e$node$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@firebase/storage/dist/node-esm/index.node.esm.js [app-ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
;
;
;
;
;
const firebaseUtils = {
    getAuth: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$node$2d$esm$2f$totp$2d$67638892$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__o__as__getAuth$3e$__["getAuth"],
    getDocs: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDocs"],
    collection: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["collection"],
    storage: __TURBOPACK__imported__module__$5b$project$5d2f$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["storage"],
    ref: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$storage$2f$dist$2f$node$2d$esm$2f$index$2e$node$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ref"],
    uploadBytes: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$storage$2f$dist$2f$node$2d$esm$2f$index$2e$node$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["uploadBytes"],
    getDownloadURL: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$storage$2f$dist$2f$node$2d$esm$2f$index$2e$node$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDownloadURL"],
    db: __TURBOPACK__imported__module__$5b$project$5d2f$config$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["db"]
};
const carBrands = [
    {
        title: "Hypercar",
        brands: [
            {
                name: "Bugatti",
                key: "bugatti"
            },
            {
                name: "Koenigsegg",
                key: "koenigsegg"
            },
            {
                name: "Pagani",
                key: "pagani"
            },
            {
                name: "Rimac",
                key: "rimac"
            },
            {
                name: "SSC",
                key: "ssc"
            }
        ]
    },
    {
        title: "Supercar",
        brands: [
            {
                name: "Mclaren",
                key: "mclaren"
            },
            {
                name: "Lamborghini",
                key: "lamborghini"
            },
            {
                name: "Ferrari",
                key: "ferrari"
            },
            {
                name: "Porsche",
                key: "porsche"
            },
            {
                name: "Aston Martin",
                key: "aston-martin"
            }
        ]
    },
    {
        title: "Luxury",
        brands: [
            {
                name: "Rolls Royce",
                key: "rolls-royce"
            },
            {
                name: "Bentley",
                key: "bentley"
            },
            {
                name: "Toyota",
                key: "toyota"
            },
            {
                name: "Mercedes-Benz",
                key: "mercedes-benz"
            },
            {
                name: "Maserati",
                key: "maserati"
            }
        ]
    },
    {
        title: "Sports Car",
        brands: [
            {
                name: "BMW",
                key: "bmw"
            },
            {
                name: "Audi",
                key: "audi"
            },
            {
                name: "Volkswagen",
                key: "volkswagen"
            },
            {
                name: "Ford",
                key: "ford"
            },
            {
                name: "Lexus",
                key: "lexus"
            }
        ]
    }
];
const fuelTypes = [
    "Electric",
    "Hybrid",
    "Petrol"
];
const transmissionTypes = [
    "Automatic",
    "Manual"
];
const bodyTypes = [
    {
        key: "sedan",
        value: "Sedan"
    },
    {
        key: "hatchback",
        value: "Hatchback"
    },
    {
        key: "coupe",
        value: "Coupe"
    },
    {
        key: "suv",
        value: "Sport Utility Vehicle (SUV)"
    },
    {
        key: "roadster",
        value: "Roadster"
    },
    {
        key: "crossover",
        value: "Crossover"
    },
    {
        key: "truck",
        value: "Pick-up Truck"
    },
    {
        key: "mpv",
        value: "Multi-purpose Vehicle (MPV)"
    },
    {
        key: "van",
        value: "Van"
    }
];
const carColors = Object.entries(__TURBOPACK__commonjs__external__tailwindcss$2f$colors__["default"]).reduce((acc, [colorName, colorShades])=>{
    if (typeof colorShades === "object" && colorShades !== null) {
        const section = {
            title: colorName.charAt(0).toUpperCase() + colorName.slice(1),
            colors: []
        };
        Object.entries(colorShades).forEach(([shade, hex])=>{
            if (!isNaN(Number(shade))) {
                section.colors.push({
                    name: `${colorName}-${shade}`,
                    key: `${colorName}-${shade}`,
                    hex: hex
                });
            }
        });
        acc.push(section);
    }
    return acc;
}, []);
// Adding a Default Colors section with "white" and "black"
carColors.unshift({
    title: "Default Colors",
    colors: [
        {
            name: "white",
            key: "white",
            hex: "#ffffff"
        },
        {
            name: "black",
            key: "black",
            hex: "#000000"
        }
    ]
});
const carFeatures = [
    {
        title: "Exterior",
        features: [
            {
                name: "Adaptive Headlights",
                key: "adaptive-headlights",
                price: 1000
            },
            {
                name: "Fog Lights",
                key: "fog-lights",
                price: 400
            },
            {
                name: "Panoramic Sunroof",
                key: "panoramic-sunroof",
                price: 2500
            },
            {
                name: "Power Tailgate",
                key: "power-tailgate",
                price: 1500
            },
            {
                name: "Roof Rails",
                key: "roof-rails",
                price: 500
            },
            {
                name: "Rain-Sensing Wipers",
                key: "rain-sensing-wipers",
                price: 300
            },
            {
                name: "Auto-Dimming Side Mirrors",
                key: "auto-dimming-side-mirrors",
                price: 350
            },
            {
                name: "LED Daytime Running Lights",
                key: "led-daytime-running-lights",
                price: 300
            },
            {
                name: "Hands-Free Trunk/Liftgate",
                key: "hands-free-liftgate",
                price: 700
            },
            {
                name: "Underbody Protection",
                key: "underbody-protection",
                price: 800
            },
            {
                name: "Tow Hitch Assist",
                key: "tow-hitch-assist",
                price: 1200
            },
            {
                name: "Run-Flat Tires",
                key: "run-flat-tires",
                price: 1000
            },
            {
                name: "Automatic High Beams",
                key: "automatic-high-beams",
                price: 600
            },
            {
                name: "Power-Folding Mirrors",
                key: "power-folding-mirrors",
                price: 500
            },
            {
                name: "Heated Side Mirrors",
                key: "heated-side-mirrors",
                price: 400
            },
            {
                name: "Carbon Fiber Exterior Options",
                key: "carbon-fiber-options",
                price: 2500
            }
        ]
    },
    {
        title: "Interior",
        features: [
            {
                name: "Adaptive Cruise Control",
                key: "adaptive-cruise-control",
                price: 2000
            },
            {
                name: "Lane Departure Warning",
                key: "lane-departure-warning",
                price: 1000
            },
            {
                name: "Blind Spot Monitoring",
                key: "blind-spot-monitoring",
                price: 1500
            },
            {
                name: "Apple CarPlay/Android Auto",
                key: "carplay-android-auto",
                price: 500
            },
            {
                name: "Heated and Ventilated Seats",
                key: "heated-ventilated-seats",
                price: 1800
            },
            {
                name: "Automatic Climate Control",
                key: "automatic-climate-control",
                price: 1200
            },
            {
                name: "Digital Instrument Cluster",
                key: "digital-instrument-cluster",
                price: 2500
            },
            {
                name: "Wireless Charging Pad",
                key: "wireless-charging-pad",
                price: 400
            },
            {
                name: "Heads-Up Display (HUD)",
                key: "heads-up-display",
                price: 2000
            },
            {
                name: "Premium Sound System",
                key: "premium-sound-system",
                price: 3000
            },
            {
                name: "Ambient Interior Lighting",
                key: "ambient-interior-lighting",
                price: 600
            },
            {
                name: "Memory Seats",
                key: "memory-seats",
                price: 1000
            },
            {
                name: "Driver Profile Settings",
                key: "driver-profile-settings",
                price: 700
            },
            {
                name: "Sunshades (Rear Window/Side Windows)",
                key: "sunshades",
                price: 400
            },
            {
                name: "Rear Seat Entertainment System",
                key: "rear-seat-entertainment",
                price: 2500
            },
            {
                name: "Rearview Camera with 360-Degree View",
                key: "rearview-360-camera",
                price: 1500
            },
            {
                name: "Voice Command",
                key: "voice-command",
                price: 800
            },
            {
                name: "Leather Upholstery",
                key: "leather-upholstery",
                price: 3000
            },
            {
                name: "Automatic Window Up/Down with Anti-Pinch",
                key: "automatic-windows",
                price: 300
            },
            {
                name: "Power Adjustable Steering Wheel",
                key: "power-steering-wheel",
                price: 1200
            },
            {
                name: "Auto-Dimming Rearview Mirror",
                key: "auto-dimming-rearview-mirror",
                price: 500
            },
            {
                name: "Remote Start",
                key: "remote-start",
                price: 700
            },
            {
                name: "Gesture Control",
                key: "gesture-control",
                price: 800
            },
            {
                name: "Tri-Zone Climate Control",
                key: "tri-zone-climate-control",
                price: 1800
            },
            {
                name: "Hands-Free Voice Assistant",
                key: "hands-free-voice-assistant",
                price: 1000
            },
            {
                name: "Multi-Function Steering Wheel",
                key: "multi-function-steering-wheel",
                price: 900
            },
            {
                name: "Driver Attention Monitoring",
                key: "driver-attention-monitoring",
                price: 1500
            },
            {
                name: "Wireless Hotspot",
                key: "wireless-hotspot",
                price: 500
            },
            {
                name: "Electronic Parking Brake",
                key: "electronic-parking-brake",
                price: 600
            },
            {
                name: "Ventilated Cupholders",
                key: "ventilated-cupholders",
                price: 200
            }
        ]
    }
];
const engineTechnologies = [
    {
        name: "Turbocharged Engine",
        key: "turbocharged-engine",
        price: 50000
    },
    {
        name: "Supercharged Engine",
        key: "supercharged-engine",
        price: 60000
    },
    {
        name: "Twin-Turbo Engine",
        key: "twin-turbo-engine",
        price: 80000
    },
    {
        name: "Twin-Charged Engine (Turbo + Supercharger)",
        key: "twin-charged-engine",
        price: 100000
    },
    {
        name: "Naturally Aspirated Engine",
        key: "naturally-aspirated-engine",
        price: 40000
    }
];
const engineTypes = [
    {
        title: "Inline Engines",
        engines: [
            {
                name: "Inline-4 (I4)",
                key: "inline-4",
                price: 30000
            },
            {
                name: "Inline-3 (I3)",
                key: "inline-3",
                price: 25000
            },
            {
                name: "Inline-6 (I6)",
                key: "inline-6",
                price: 40000
            },
            {
                name: "Inline-5 (I5)",
                key: "inline-5",
                price: 35000
            },
            {
                name: "Inline-2 (I2)",
                key: "inline-2",
                price: 20000
            }
        ]
    },
    {
        title: "V Engines",
        engines: [
            {
                name: "V6",
                key: "v6",
                price: 50000
            },
            {
                name: "V8",
                key: "v8",
                price: 70000
            },
            {
                name: "V10",
                key: "v10",
                price: 90000
            },
            {
                name: "V12",
                key: "v12",
                price: 110000
            },
            {
                name: "V16",
                key: "v16",
                price: 150000
            }
        ]
    },
    {
        title: "W Engines",
        engines: [
            {
                name: "W12",
                key: "w12",
                price: 130000
            },
            {
                name: "W16",
                key: "w16",
                price: 170000
            }
        ]
    }
];
const driveType = [
    {
        name: "Rear Wheel Drive",
        key: "RWD"
    },
    {
        name: "Front Wheel Drive",
        key: "FWD"
    },
    {
        name: "All Wheel Drive",
        key: "AWD"
    }
];

})()),
"[project]/app/sell/details/page.tsx [app-ssr] (ecmascript)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__ }) => (() => {
"use strict";

__turbopack_esm__({
    "default": ()=>CarDetails
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/server/future/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$context$2f$VehicleContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/app/context/VehicleContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$sellingCarData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/app/data/sellingCarData.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nextui$2d$org$2f$button$2f$dist$2f$chunk$2d$DBLREEYE$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__button_default__as__Button$3e$__ = __turbopack_import__("[project]/node_modules/@nextui-org/button/dist/chunk-DBLREEYE.mjs [app-ssr] (ecmascript) <export button_default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nextui$2d$org$2f$card$2f$dist$2f$chunk$2d$H4VOEXHF$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__card_default__as__Card$3e$__ = __turbopack_import__("[project]/node_modules/@nextui-org/card/dist/chunk-H4VOEXHF.mjs [app-ssr] (ecmascript) <export card_default as Card>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nextui$2d$org$2f$card$2f$dist$2f$chunk$2d$5ALFRFZW$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__card_body_default__as__CardBody$3e$__ = __turbopack_import__("[project]/node_modules/@nextui-org/card/dist/chunk-5ALFRFZW.mjs [app-ssr] (ecmascript) <export card_body_default as CardBody>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nextui$2d$org$2f$image$2f$dist$2f$chunk$2d$NK4BRF7C$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__image_default__as__Image$3e$__ = __turbopack_import__("[project]/node_modules/@nextui-org/image/dist/chunk-NK4BRF7C.mjs [app-ssr] (ecmascript) <export image_default as Image>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
"__TURBOPACK__ecmascript__hoisting__location__";
"use client";
;
;
;
;
;
// Utility functions for mapping keys to names
function getFeatureNameByKey(key) {
    for (const category of __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$sellingCarData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["carFeatures"]){
        for (const feature of category.features){
            if (feature.key === key) {
                return feature.name;
            }
        }
    }
    return key;
}
function getBrandNameByKey(key) {
    for (const category of __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$sellingCarData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["carBrands"]){
        for (const brand of category.brands){
            if (brand.key === key) {
                return brand.name;
            }
        }
    }
    return key;
}
function getFuelTypeNameByKey(key) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$sellingCarData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["fuelTypes"].includes(key) ? key : key;
}
function getTransmissionTypeNameByKey(key) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$sellingCarData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["transmissionTypes"].includes(key) ? key : key;
}
function getBodyTypeNameByKey(key) {
    const bodyType = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$sellingCarData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["bodyTypes"].find((body)=>body.key === key);
    return bodyType ? bodyType.value : key;
}
function getColorNameByKey(key) {
    for (const section of __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$sellingCarData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["carColors"]){
        for (const color of section.colors){
            if (color.key === key) {
                return color.name;
            }
        }
    }
    return key;
}
function getEngineTechnologyNameByKey(key) {
    const technology = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$sellingCarData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["engineTechnologies"].find((tech)=>tech.key === key);
    return technology ? technology.name : key;
}
function getEngineTypeNameByKey(key) {
    for (const category of __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$sellingCarData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["engineTypes"]){
        for (const engine of category.engines){
            if (engine.key === key) {
                return engine.name;
            }
        }
    }
    return key;
}
function getDriveTypeNameByKey(key) {
    const drive = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$data$2f$sellingCarData$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["driveType"].find((type)=>type.key === key);
    console.log(drive);
    return drive ? drive.name : key;
}
function CarDetails() {
    const { selectedCar } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$context$2f$VehicleContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCar"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    if (!selectedCar) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "container mx-auto px-4 py-8",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "text-2xl font-bold mb-4",
                    children: "No Car Selected"
                }, void 0, false, {
                    fileName: "[project]/app/sell/details/page.tsx",
                    lineNumber: 93,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "Please go back to the car list and select a car."
                }, void 0, false, {
                    fileName: "[project]/app/sell/details/page.tsx",
                    lineNumber: 94,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nextui$2d$org$2f$button$2f$dist$2f$chunk$2d$DBLREEYE$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__button_default__as__Button$3e$__["Button"], {
                    onClick: ()=>router.push("/sell"),
                    children: "Go Back"
                }, void 0, false, {
                    fileName: "[project]/app/sell/details/page.tsx",
                    lineNumber: 95,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/sell/details/page.tsx",
            lineNumber: 92,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative min-h-screen grid w-full grid-cols-3 gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: " fixed top-0 left-0 w-2/3 h-full flex flex-col justify-center items-center p-20",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-[70vh] flex items-center justify-center",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nextui$2d$org$2f$image$2f$dist$2f$chunk$2d$NK4BRF7C$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__image_default__as__Image$3e$__["Image"], {
                                    isBlurred: true,
                                    alt: `${getBrandNameByKey(selectedCar.brand)} ${selectedCar.model}`,
                                    className: "object-cover rounded-xl max-h-full",
                                    src: selectedCar.modelimg
                                }, void 0, false, {
                                    fileName: "[project]/app/sell/details/page.tsx",
                                    lineNumber: 106,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/sell/details/page.tsx",
                                lineNumber: 105,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between items-center w-full mt-4 text-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-xl font-bold text-orange-500",
                                                children: [
                                                    selectedCar.hp,
                                                    " hp"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/sell/details/page.tsx",
                                                lineNumber: 115,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-md",
                                                children: "Power"
                                            }, void 0, false, {
                                                fileName: "[project]/app/sell/details/page.tsx",
                                                lineNumber: 118,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/sell/details/page.tsx",
                                        lineNumber: 114,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-xl font-bold text-orange-500",
                                                children: [
                                                    selectedCar.topspeed,
                                                    " km/h"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/sell/details/page.tsx",
                                                lineNumber: 121,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-md",
                                                children: "Top Speed"
                                            }, void 0, false, {
                                                fileName: "[project]/app/sell/details/page.tsx",
                                                lineNumber: 124,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/sell/details/page.tsx",
                                        lineNumber: 120,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-xl font-bold text-orange-500",
                                                children: [
                                                    selectedCar.mileage,
                                                    " km"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/sell/details/page.tsx",
                                                lineNumber: 127,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-md",
                                                children: "Mileage"
                                            }, void 0, false, {
                                                fileName: "[project]/app/sell/details/page.tsx",
                                                lineNumber: 130,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/sell/details/page.tsx",
                                        lineNumber: 126,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-xl font-bold text-orange-500",
                                                children: getBodyTypeNameByKey(selectedCar.body)
                                            }, void 0, false, {
                                                fileName: "[project]/app/sell/details/page.tsx",
                                                lineNumber: 133,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-md",
                                                children: "Body Type"
                                            }, void 0, false, {
                                                fileName: "[project]/app/sell/details/page.tsx",
                                                lineNumber: 136,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/sell/details/page.tsx",
                                        lineNumber: 132,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/sell/details/page.tsx",
                                lineNumber: 113,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/sell/details/page.tsx",
                        lineNumber: 104,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "col-span-2"
                    }, void 0, false, {
                        fileName: "[project]/app/sell/details/page.tsx",
                        lineNumber: 141,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "col-span-1 ml-0 p-9",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-2xl text-left font-bold mb-4",
                                children: "Engines"
                            }, void 0, false, {
                                fileName: "[project]/app/sell/details/page.tsx",
                                lineNumber: 145,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-2 gap-4",
                                children: Array.isArray(selectedCar.enginetype) ? selectedCar.enginetype.map((engineKey)=>// <div
                                    //   key={engineKey}
                                    //   className="border p-4 rounded-lg shadow-sm"
                                    // >
                                    // </div>
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nextui$2d$org$2f$card$2f$dist$2f$chunk$2d$H4VOEXHF$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__card_default__as__Card$3e$__["Card"], {
                                        isPressable: true,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nextui$2d$org$2f$card$2f$dist$2f$chunk$2d$5ALFRFZW$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__card_body_default__as__CardBody$3e$__["CardBody"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "text-lg font-bold",
                                                    children: getEngineTypeNameByKey(engineKey)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/sell/details/page.tsx",
                                                    lineNumber: 157,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-xs text-gray-500",
                                                    children: [
                                                        "Fuel Type: ",
                                                        getFuelTypeNameByKey(selectedCar.fuel)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/sell/details/page.tsx",
                                                    lineNumber: 160,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "mt-2 font-semibold",
                                                    children: [
                                                        "From RM ",
                                                        Number(selectedCar.price).toLocaleString()
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/sell/details/page.tsx",
                                                    lineNumber: 163,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "mt-4",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "font-bold",
                                                            children: "Transmission"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/sell/details/page.tsx",
                                                            lineNumber: 168,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            children: getTransmissionTypeNameByKey(selectedCar.transmission)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/sell/details/page.tsx",
                                                            lineNumber: 169,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/sell/details/page.tsx",
                                                    lineNumber: 167,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    className: "mt-4 text-blue-600 font-semibold hover:underline focus:outline-none",
                                                    type: "button",
                                                    children: "Transmission & Technical Data"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/sell/details/page.tsx",
                                                    lineNumber: 174,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/sell/details/page.tsx",
                                            lineNumber: 156,
                                            columnNumber: 19
                                        }, this)
                                    }, engineKey, false, {
                                        fileName: "[project]/app/sell/details/page.tsx",
                                        lineNumber: 155,
                                        columnNumber: 17
                                    }, this)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "border p-4 rounded-lg shadow-sm",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "text-lg font-bold",
                                            children: getEngineTypeNameByKey(selectedCar.enginetype)
                                        }, void 0, false, {
                                            fileName: "[project]/app/sell/details/page.tsx",
                                            lineNumber: 185,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-xs text-gray-500",
                                            children: [
                                                "Fuel Type: ",
                                                getFuelTypeNameByKey(selectedCar.fuel)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/sell/details/page.tsx",
                                            lineNumber: 188,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "mt-2 font-semibold",
                                            children: [
                                                "From RM ",
                                                Number(selectedCar.price).toLocaleString()
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/sell/details/page.tsx",
                                            lineNumber: 191,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mt-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "font-bold",
                                                    children: "Transmission"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/sell/details/page.tsx",
                                                    lineNumber: 196,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    children: getTransmissionTypeNameByKey(selectedCar.transmission)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/sell/details/page.tsx",
                                                    lineNumber: 197,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/sell/details/page.tsx",
                                            lineNumber: 195,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            className: "mt-4 text-blue-600 font-semibold hover:underline focus:outline-none",
                                            type: "button",
                                            children: "Transmission & Technical Data"
                                        }, void 0, false, {
                                            fileName: "[project]/app/sell/details/page.tsx",
                                            lineNumber: 202,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/sell/details/page.tsx",
                                    lineNumber: 184,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/sell/details/page.tsx",
                                lineNumber: 146,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/sell/details/page.tsx",
                        lineNumber: 144,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/sell/details/page.tsx",
                lineNumber: 102,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed bottom-0 left-0 w-full bg-neutral-100 dark:bg-neutral-900 border-t border-neutral-300 dark:border-neutral-800 shadow-lg py-4 z-50",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container mx-auto flex justify-between items-center px-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-2xl font-bold",
                                children: [
                                    getBrandNameByKey(selectedCar.brand),
                                    " ",
                                    selectedCar.model
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/sell/details/page.tsx",
                                lineNumber: 218,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/sell/details/page.tsx",
                            lineNumber: 217,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-4 items-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-col items-start",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-md text-orange-500",
                                            children: "Total Price:"
                                        }, void 0, false, {
                                            fileName: "[project]/app/sell/details/page.tsx",
                                            lineNumber: 224,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-xl font-bold text-orange-500",
                                            children: [
                                                "RM",
                                                Number(selectedCar.price).toLocaleString()
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/sell/details/page.tsx",
                                            lineNumber: 225,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/sell/details/page.tsx",
                                    lineNumber: 223,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$future$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$nextui$2d$org$2f$button$2f$dist$2f$chunk$2d$DBLREEYE$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__button_default__as__Button$3e$__["Button"], {
                                    color: "primary",
                                    onClick: ()=>alert("Summary Saved!"),
                                    children: "Save Summary"
                                }, void 0, false, {
                                    fileName: "[project]/app/sell/details/page.tsx",
                                    lineNumber: 229,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/sell/details/page.tsx",
                            lineNumber: 222,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/sell/details/page.tsx",
                    lineNumber: 216,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/sell/details/page.tsx",
                lineNumber: 215,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}

})()),
"[project]/app/sell/details/page.tsx [app-rsc] (ecmascript, Next.js server component, client modules ssr)": (({ r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, g: global, __dirname }) => (() => {


})()),

};

//# sourceMappingURL=app_b10674._.js.map