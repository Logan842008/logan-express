import { nextui } from "@nextui-org/theme";

/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./node_modules/@nextui-org/theme/dist/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  darkMode: "class", // Enables dark mode using class strategy
  plugins: [
    nextui({
      themes: {
        light: {
          colors: {
            background: "#FFFFFF", // or DEFAULT
            foreground: "#11181C", // or 50 to 900 DEFAULT
            primary: {
              //... 50 to 900
              foreground: "#FFFFFF",
              DEFAULT: "#f97316",
            },
            // warning: {
            //   foreground: "#FFFFFF",
            //   DEFAULT: "#f97316",
            // },
            // ... rest of the colors
            focus: "#f97316",
          },
        },
        dark: {
          colors: {
            background: "#000000", // or DEFAULT
            foreground: "#ECEDEE", // or 50 to 900 DEFAULT
            primary: {
              //... 50 to 900
              foreground: "#FFFFFF",
              DEFAULT: "#f97316",
            },
            // warning: {
            //   foreground: "#FFFFFF",
            //   DEFAULT: "#f97316",
            // },
            focus: "#f97316",
          },
          // ... rest of the colors
        },
      },
    }),
  ],
};

// 006FEE
